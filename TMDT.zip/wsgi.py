# Run server
from app import app
if __name__ == '__main__':
    app.run(port=1000, debug=True)
