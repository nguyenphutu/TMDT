"""empty message

Revision ID: d9ab0b08f761
Revises: 
Create Date: 2017-10-13 10:22:12.122159

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = 'd9ab0b08f761'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass

def downgrade():
    pass
